//**************************************************************************************************************
// Librerias
//**************************************************************************************************************
#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"


#define XTAL 16000000

//**************************************************************************************************************
// FUNCIONES NOMBRES
//**************************************************************************************************************
void delay(uint32_t msec);
void delay1ms(void);

//**************************************************************************************************************
// VARIABLES
//**************************************************************************************************************

unsigned char valueSEG[] = {0b0111111, 0b0000110, 0b1011011, 0b1001111, 0b01100110, 0b1101101, 0b1111101, 0b0000111, 0b1111111, 0b1101111, 0b1110111, 0b1111100, 0b0111001, 0b01011110, 0b1111001, 0b1110001};
unsigned char Anim[] = {0b10000000, 0b10010000, 0b10100000, 0b10000001, 0b10000010, 0b1000100, 0b00000000};
unsigned char SEG[] = {0}; // DISPLAY FISICO
uint32_t  dippressed1, dippressed2;
uint32_t i = 0;
int contador = 0;
int estado, lestado;
int estado2, lestado2;
int bandera = 0;
int bandera1 = 0;
uint32_t ui32Period;
int LEDS = 0;


//**************************************************************************************************************
//BOTONES
//**************************************************************************************************************
int main(void){
    // 16MHZ
SysCtlClockSet(SYSCTL_SYSDIV_2_5|SYSCTL_USE_PLL|SYSCTL_OSC_MAIN|SYSCTL_XTAL_16MHZ);

//RELOJ PARA LOS PERIFELALES
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

// Se habilita el reloj para el temporizador
SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

// Configuración del Timer 0 como temporizador per�odico
TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

// Se calcula el período para el temporizador (1 seg)
ui32Period = (SysCtlClockGet()) / 2;
// Establecer el periodo del temporizador
TimerLoadSet(TIMER0_BASE, TIMER_A, ui32Period - 1);

// Se habilita la interrupción por el TIMER0A
IntEnable(INT_TIMER0A);
// Se establece que exista la interrupción por Timeout
TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
// Se habilitan las interrupciones Globales
IntMasterEnable();
// Se habilita el Timer
TimerEnable(TIMER0_BASE, TIMER_A);

// INPUT
GPIOPinTypeGPIOInput(GPIO_PORTD_BASE,GPIO_PIN_0| GPIO_PIN_1| GPIO_PIN_6 | GPIO_PIN_3); //PB6 Y PB7 2DIPS

// PULL UP
GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_0| GPIO_PIN_1| GPIO_PIN_6 | GPIO_PIN_3, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);

//OUPUT PUERTO E Y PUERTO F
GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1| GPIO_PIN_2| GPIO_PIN_3); //leds
GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3| GPIO_PIN_4| GPIO_PIN_5| GPIO_PIN_6| GPIO_PIN_7); //PA 7SEG

//LECTURA DE DATOS
while(1){
        dippressed1 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_6 | GPIO_PIN_3);

// PARTE 1
        switch(dippressed1){
        case 0x00:
            break;

// PARTE 2
        case 0b00001000:

           estado = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_0);
           estado2 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_1);

            if(estado != lestado){
                if(estado == 0){
                    contador++;
                    }
                    lestado = estado;
                }

                if(estado2 != lestado2){
                    if(estado2 == 0){
                        contador--;
                    }
                    lestado2 = estado2;
                }

                GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1| GPIO_PIN_2| GPIO_PIN_3, contador);

                if(contador > 16){ //2^4 LEDS
                    contador = 0;
                }

                else if(contador < 0){
                    contador = 16;
                }

              // FIN DE LEDS



            break; // FIN DE PARTE 2

        case 0b01000000:  //ANIMACION (PARTE 3)
            break;

        case 0b01001000: // PARTE 3
            break;

        default:
            break;
        }
    }
}

//**************************************************************************************************************
// FUNCIONES
//**************************************************************************************************************

//INTERRUPCION DEL TIMER0

void Timer0IntHandler(void)
{


    // Clear the timer interrupt
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    if(dippressed1 == 0b00001000){

        if(bandera > 15) // DE 0 A F
            bandera = 0;

        GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3| GPIO_PIN_4| GPIO_PIN_5| GPIO_PIN_6 | GPIO_PIN_7, valueSEG[bandera]);
        bandera++;
    }

    if (dippressed1 == 0b01000000){

        if(bandera1 > 6) //LARGO DE LA ANIMACION
            bandera1 = 0;

        GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3| GPIO_PIN_4| GPIO_PIN_5| GPIO_PIN_6 | GPIO_PIN_7 , Anim[bandera1]);
        bandera1++;

        // ANIMACION
        if(LEDS%2 == 0){
            GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_2, GPIO_PIN_0 | GPIO_PIN_2); //leds
            GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1 | GPIO_PIN_3, 0x00); //leds

        }
        else if(LEDS%3 == 0){
            GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1 | GPIO_PIN_3, GPIO_PIN_1| GPIO_PIN_3); //leds
            GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_2, 0x00); //leds
        }

        LEDS++; //TEMPO PARA LA ANIMACION EN LOS LEDS
    }



}
